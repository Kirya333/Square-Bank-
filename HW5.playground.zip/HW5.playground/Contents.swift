import UIKit


enum EngineState: String {
    case on = "заведен", off = "заглушен"
}

enum WindowState: String {
    case open = "Окна открыты", close = "Окна закрыты"
}

enum DoorState: String {
    case open = "Двери открыт", close = "Двери закрыты"
}

enum RoofState: String {
    case open = "Открыта", close = "Закрыта"
}

enum TrunkState: String {
    case full = "Полный", empty = "Пустой"
}

protocol Car: class, CustomStringConvertible {
    
    var brand: String { get }
    var engineState: EngineState { get set }
    var windowState: WindowState { get set }
    var doorState: DoorState { get set }
    var yearOfIssue: Int { get }
    var km: Double { get set }
    var vehicleWeight: Double { get set }
    
    
    func changeEngineState( to: EngineState)
    func changeWindowState( to: WindowState)
    func changeDoorState(to: DoorState)
    
}


extension Car {
    
    func changeEngineState( to: EngineState) {
        engineState = to
    }
    func changeWindowState( to: WindowState) {
        windowState = to
    }
    
    func changeDoorState( to: DoorState) {
        doorState = to
    }
    
    var description: String {
        return "Бренд авто: \(brand), состояние двигателя авто: \(engineState.rawValue), состояние окон авто: \(windowState.rawValue), состояние дверей авто: \(doorState.rawValue), пробег авто: \(km), год выпуска авто: \(yearOfIssue), вес авто: \(vehicleWeight)"
    }
    
}


class SportCar: Car {
    var brand: String
    var yearOfIssue: Int
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    var km: Double
    var vehicleWeight: Double
    var roofState: RoofState
    
    init(brand: String, yearOfIssue: Int, engineState: EngineState, windowState: WindowState, doorState: DoorState, km: Double, vehicleWeight: Double, roofState: RoofState) {
        self.brand = brand
        self.yearOfIssue = yearOfIssue
        self.km = km
        self.vehicleWeight = vehicleWeight
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
        self.roofState = roofState
    }
    
    func changeRoofState(to: RoofState) {
        roofState = to
    }
    
}



class TrunkCar: Car {
    var brand: String
    var yearOfIssue: Int
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    var km: Double
    var vehicleWeight: Double
    var trunkState: TrunkState
    
    
    func changeKm( to newKm: Double) {
        self.km = newKm
    }

    init(brand: String, yearOfIssue: Int, engineState: EngineState, windowState: WindowState, doorState: DoorState, km: Double, vehicleWeight: Double, trunkState: TrunkState) {
        self.brand = brand
        self.yearOfIssue = yearOfIssue
        self.km = km
        self.vehicleWeight = vehicleWeight
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
        self.trunkState = trunkState
        
    }


    func changeTrunkState(to: TrunkState) {
        trunkState = to
    }

}

extension SportCar {
    var description: String {
        return "Бренд авто: \(brand), состояние двигателя авто: \(engineState.rawValue), состояние окон авто: \(windowState.rawValue), состояние дверей авто: \(doorState.rawValue), пробег авто: \(km), год выпуска авто: \(yearOfIssue), вес авто: \(vehicleWeight), состояние крыши: \(roofState.rawValue)"
    }
}


extension TrunkCar {
    var description: String {
        return "Бренд авто: \(brand), состояние двигателя авто: \(engineState.rawValue), состояние окон авто: \(windowState.rawValue), состояние дверей авто: \(doorState.rawValue), пробег авто: \(km), год выпуска авто: \(yearOfIssue), вес авто: \(vehicleWeight), состояние груза \(trunkState.rawValue)"
        
    }
}

var SportCarMers = SportCar(brand: "Mercedes", yearOfIssue: 2021, engineState: .off, windowState: .close, doorState: .close, km: 0, vehicleWeight: 2500, roofState: .close)

var SportCarBMW = SportCar(brand: "BMW", yearOfIssue: 2015, engineState: .on, windowState: .open, doorState: .open, km: 400, vehicleWeight: 3000, roofState: .open)

var TrunkCarVolvo = TrunkCar(brand: "Volvo", yearOfIssue: 2021, engineState: .off, windowState: .close, doorState: .close, km: 1, vehicleWeight: 5500, trunkState: .empty)

var TrunkCarKamaz = TrunkCar(brand: "Камаз", yearOfIssue: 2005, engineState: .on, windowState: .open, doorState: .open, km: 700, vehicleWeight: 8000, trunkState: .full)


SportCarMers.changeRoofState(to: .open)
SportCarBMW.changeEngineState(to: .off)
TrunkCarVolvo.changeKm(to: 100)
TrunkCarKamaz.changeTrunkState(to: .empty)

func valuePrint(_value: Car) {
    print(_value, "\n")
}


valuePrint(_value: SportCarMers)

valuePrint(_value: SportCarBMW)

valuePrint(_value: TrunkCarVolvo)

valuePrint(_value: TrunkCarKamaz)



