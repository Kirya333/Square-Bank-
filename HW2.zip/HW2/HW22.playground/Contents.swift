import UIKit


func evenNumber(value: Int) {
    if value % 2 == 1 {
        print("Нечетное")
    } else {
        print("Четное")
    }

}

evenNumber(value: 75)

func deviciom(value: Int) {
    if value % 3 == 0 {
        print("Все отлично делится!")
    } else {
        print("Упс! Не получилось")
    }
}

deviciom(value: 99)

let oneHudred = Array<Int>(1...100)
 
 





