//
//  main.swift
//  HW2
//
//  Created by Кирилл on 05.04.2021.
//

import Foundation


func evenNumber(value: Int) {
    if value % 2 == 1 {
        print("Нечетное")
    } else {
        print("Четное")
    }

}

evenNumber(value: 74)

func devicion(value: Int) {
    if value % 3 == 0 {
        print("Все отлично делится!")
    } else {
        print("Упс! Не получилось")
    }
}

devicion(value: 97)

let oneHundred = Array<Int>(1...100)

/*let filtred = oneHudred.filter{$0 % 2 == 1; return $0 % 3 == 1}
print(filtred)

for element in oneHudred where element % 2 == 1 {
    print(element)
}; for element in oneHudred where element % 3 == 1 {
    print(element)
}*/

let filtred = oneHundred.filter {$0 % 2 == 1 && $0 % 3 == 1}
   print(filtred)


func fibonacciArray(_ n: Int) -> [Double] {
    var fibonacci: [Double] = [1, 1]
    (2...n).forEach{ i in
        fibonacci.append(fibonacci[i - 1] + fibonacci[i - 2])
    }
    return fibonacci
}
print(fibonacciArray(50))
