import UIKit


struct Money {
    var amount: Decimal
    var currency: String
}

extension Money: CustomStringConvertible {
    var description: String { "\(amount) \(currency)" }
}

enum BankAccountError: Error {
    case insufficientAmount
    case convertionError(providedCurrency: String, acountCurrency: String)
    case fraudWarning
    
    var localizedDescription: String {
        switch self {
        case.insufficientAmount:
            return "Не достаточно средств на счете"
        case.convertionError(let provided, let supported):
            return "Ошибка вывода средств в \(provided). Валюта счета: \(supported)"
        case.fraudWarning:
            return "Мошенничесвто уголовно наказуемо!"
        }
    }
}

extension BankAccountError: CustomStringConvertible {
    var description: String { self.localizedDescription}
}

class BankAccount {
    var balance: Money
    
    init(initialBalance: Money) {
        balance = initialBalance
    }
    
    func deposit (money: Money) -> BankAccountError? {
        guard money.amount > 0 else { return BankAccountError.fraudWarning }
        
        guard money.currency == balance.currency else {
            return BankAccountError.convertionError(providedCurrency: money.currency,
                                                    acountCurrency: balance.currency)
        }
        
        balance.amount += money.amount
        return nil
    }
    
    func withdraw(amount: Decimal) -> (amount: Money?, error: BankAccountError?) {
        
        guard amount > 0 else { return (amount: nil, error: BankAccountError.fraudWarning)}
        
        guard amount <= balance.amount else {
            
            return (amount: nil, error: BankAccountError.insufficientAmount)
        }
        
        balance.amount -= amount
            
            return (amount: Money(amount: amount, currency: balance.currency), error: nil)
        }
    }

    extension BankAccount: CustomStringConvertible {
        var description: String {
            "Состояние счета: \(balance)"
        }
    }
    
    var account = BankAccount(initialBalance: Money(amount: 5000.0, currency: "USD"))
    
    if let error = account.deposit(money: Money(amount: -500, currency: "USD")) {
        print("Внимание! \(error)")
    } else {
        print(account)
    }
    
    let result = account.withdraw(amount: 3000.0)
    
    if let amount = result.amount {
        print("Вы ввели: \(amount).\(account)")
    } else if let error = result.error {
        print(error)
    }


extension BankAccount {
    func unsafeDeposit(money: Money) throws {
        guard money.amount > 0 else {
            throw BankAccountError.fraudWarning
        }
        
        guard money.currency == balance.currency else {
            throw BankAccountError.convertionError(
                providedCurrency: money.currency,
                acountCurrency: balance.currency)
        }
        
        balance.amount += money.amount
    }
    
    func unsafeWithdraw(amount: Decimal) throws -> Money {
        guard amount > 0 else { throw BankAccountError.fraudWarning}
        
        guard amount <= balance.amount else { throw BankAccountError.insufficientAmount }
        
        balance.amount -= amount
        
        return Money(amount: amount, currency: balance.currency)
    }
}

do {
    let money = try account.unsafeWithdraw(amount: 4500.0)
    print("Снял денег: \(money)")

} catch let error {
    print(error)
}

do {
    let newAmount = Money(amount: 3300, currency: "USD")
    try account.unsafeDeposit(money: newAmount)
    
} catch BankAccountError.fraudWarning {
    print("Запрещено!")
    
} catch BankAccountError.convertionError(let provided, let supported) {
    print("\(supported) и \(provided) разные вещи!")
    
} catch let error {
    print(error.localizedDescription)
}















//class RateCurrency {
//
//    var currencies = [
//        "USD": 75,
//        "EUR": 90,
//        "GBP": 105,
//        "SEK": 9
//    ]
//
//    func magnitude(nameCurrency: String) -> Int? {
//        return currencies[nameCurrency]
//    }
//
//func averageCurrency() -> Int {
//
//        guard currencies.count > 1 else {
//            return 0
//        }
//        var totalCurrency = 0
//        for currency in currencies {
//            totalCurrency += currency.value
//        }
//        return totalCurrency / currencies.count
//    }
//
//}
//
//let rateCurrency = RateCurrency()
//
//rateCurrency.averageCurrency()
//
//


//
//struct Laptop {
//
//    var model: String
//    var yaerOfIssue: Int
//    let osName: OsName
//
//}
//
//struct OsName {
//
//    let name: String
//
//
//}
//
//class OsServer {
//
//    var inventory = [
//        "MacOS": Laptop(model: "Mac", yaerOfIssue: 2015, osName: OsName(name: "MacOs")),
//        "Winows": Laptop(model: "Acer", yaerOfIssue: 2018, osName: OsName(name: "Windows")),
//        "Linux": Laptop(model: "Lenovo", yaerOfIssue: 2019, osName: OsName(name: "Linux"))
//    ]
//
//    func updates(osNamed name: String) -> OsName? {
//
//        guard let Laptop = inventory[name] else { return nil }
//
//        guard Laptop(model."Mac").yearOfIssue > 2015 else { return nil }
//        guard Laptop(name."Acer").yearOfIssue > 2018 else { return nil }
//        guard Laptop(name."Lenovo").yearOfIssue > 2019 else { return nil }
//
//
//        guard let Laptop == Laptop[name] else { return nil }
//
//
//
//
//    }
//
//}





