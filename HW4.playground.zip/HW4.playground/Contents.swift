import UIKit


enum EngineState {
    case on, off
}

enum WindowState: String {
    case open = "Открыты окна", close = "Закрыты окна"
}

enum DoorState {
    case open, close
}

enum RoofState {
    case open, close
}

enum Trunk {
    case be, not
}

class Car {
    
    let brand: String
    var engineState: EngineState
    var windowState: WindowState
    var doorState: DoorState
    var km: Double
    let yearOfIssue: Int

    
    init (brand: String, engineState: EngineState, windowState: WindowState, doorState: DoorState, km: Double, yearOfIssue: Int) {
        self.brand = brand
        self.engineState = engineState
        self.windowState = windowState
        self.doorState = doorState
        self.km = km
        self.yearOfIssue = yearOfIssue
    }
    
    func changeEngineState(to: EngineState) {}
    func changeWindowState(to: WindowState) {}
    func changeDoorState(to: DoorState) {}
    
    func printDetail() {
        print(self.windowState.rawValue)
    }
}


class SportCar: Car {
    
    var roof: RoofState
    
    init(brand: String, engineState: EngineState, windowState: WindowState, doorState: DoorState, km: Double, yearOfIssue: Int, roof: RoofState) {
    
    self.roof = roof
    
    super.init(brand: brand, engineState: engineState, windowState: windowState, doorState: doorState, km: km, yearOfIssue: yearOfIssue)
    
}

    func changeRoofState(to: RoofState) {
        
        roof = to
        
    }


    func alarmOFF() {
        engineState = .on
        windowState = .open
        doorState = .open
        
    }

    func alarmON() {
        engineState = .off
        windowState = .close
        doorState = .close
    }

    override func changeWindowState(to: WindowState) {
        windowState = to
    }

    override func changeDoorState(to: DoorState) {
        doorState = to
    }

    override func changeEngineState(to: EngineState) {
        engineState = to
    }

}

class TrunkCar: Car {
    
    var trunk: Trunk
    
    init(brand: String, engineState: EngineState, windowState: WindowState, doorState: DoorState, km: Double, yearOfYssue: Int, trunk: Trunk) {
        
        self.trunk = trunk
        
        super.init(brand: brand, engineState: engineState, windowState: windowState, doorState: doorState, km: km, yearOfIssue: yearOfYssue)
    }
    
    override func changeEngineState(to: EngineState) {
        engineState = to
    }
    
    override func changeDoorState(to: DoorState) {
        doorState = to
    }
 
    override func changeWindowState(to: WindowState) {
        windowState = to
    }
    
    override func printDetail() {
        super.printDetail()
        print(self.trunk)
    }
}

    
var SportCarMers = SportCar (brand: "Mercedes", engineState: .off, windowState: .close, doorState: .close, km: 0, yearOfIssue: 2021, roof: .close)

var SportCarLexus = SportCar (brand: "Lexus", engineState: .on, windowState: .open, doorState: .open, km: 250, yearOfIssue: 2010, roof: .open)

var TrunkCarVolvo = TrunkCar (brand: "Volvo", engineState: .off, windowState: .close, doorState: .close, km: 0, yearOfYssue: 2021, trunk: .be)

var TrunkCarWW = TrunkCar (brand: "WW", engineState: .on, windowState: .open, doorState: .open, km: 150, yearOfYssue: 2011, trunk: .not)


SportCarMers.doorState
SportCarMers.engineState
SportCarMers.windowState.rawValue

SportCarMers.alarmON()

SportCarMers.doorState
SportCarMers.engineState
SportCarMers.windowState.rawValue

SportCarLexus.roof
SportCarLexus.changeRoofState(to: .close)
SportCarLexus.roof

TrunkCarVolvo.doorState
TrunkCarVolvo.trunk
TrunkCarVolvo.changeDoorState(to: .open)
TrunkCarVolvo.changeWindowState(to: .open)
TrunkCarVolvo.doorState
TrunkCarVolvo.windowState

TrunkCarWW.engineState
TrunkCarWW.trunk
TrunkCarWW.km
TrunkCarWW.changeEngineState(to: .off)
TrunkCarWW.km = 500
TrunkCarWW.engineState
TrunkCarWW.km

TrunkCarWW.printDetail()








