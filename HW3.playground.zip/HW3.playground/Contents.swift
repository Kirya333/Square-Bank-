import UIKit

enum Transmission {
    case auto, manual
}
enum EngineState {
    case on, off
}
enum WindowState {
    case open, closed
}

struct TrunkCar {
    let brand: String
    let yearOfIssue: Int
    var trunkCapacity: Double
    var trunkFilledCapacity: Double
    var engineState: EngineState
    var windowState: WindowState
    
    mutating func windowState(_ windowState: WindowState){
        self.windowState = windowState
    }
    mutating func engineState(_ engineState: EngineState){
        self.engineState = engineState
    }
}

struct SportCar {
    let brand: String
    let yearOfIssue: Int
    var trunkCapacity: Double
    var trunkFilledCapacity: Double
    var engineState: EngineState
    var windowState: WindowState
    
    
    mutating func windowState(_ windowState: WindowState){
        self.windowState = windowState
    }
    mutating func engineState(_ engineState: EngineState){
        self.engineState = engineState
    }
}

func printTrunkCarProperties (car: TrunkCar){
    print("Марка: \(car.brand)")
    print("Год выпуска: \(car.yearOfIssue)")
    print("Объем багажника: \(car.trunkCapacity) литров")
    print("Заполненный объем багажника: \(car.trunkFilledCapacity) литров")
    print("Состояние двигателя: \(car.engineState == .on ? "включен" : "выключен")")
    print("Состояние окон: \(car.windowState == .open ? "Открыты" : "Закрыты")")
    
}

func printSportCarProperties (car: SportCar){
    print("Марка: \(car.brand)")
    print("Год выпуска: \(car.yearOfIssue)")
    print("Объем багажника: \(car.trunkCapacity) литров")
    print("Заполненный объем багажника: \(car.trunkFilledCapacity) литров")
    print("Состояние двигателя: \(car.engineState == .on ? "включен" : "выключен")")
    print("Состояние окон: \(car.windowState == .open ? "Открыты" : "Закрыты")")
    
}

var sportCarMers = SportCar(brand: "Mersedes", yearOfIssue: 2020, trunkCapacity: 300, trunkFilledCapacity: 150, engineState: .on, windowState: .closed)

var sportCarBMW = SportCar(brand: "BMW", yearOfIssue: 2010, trunkCapacity: 200, trunkFilledCapacity: 100, engineState: .off, windowState: .open)


sportCarMers.engineState = .off
sportCarBMW.trunkFilledCapacity = 150


var trunkCarVolvo = TrunkCar(brand: "Volvo", yearOfIssue: 2018, trunkCapacity: 2000, trunkFilledCapacity: 1800, engineState: .on, windowState: .closed)

var trunkCarKamaz = TrunkCar(brand: "Kamaz", yearOfIssue: 2007, trunkCapacity: 1500, trunkFilledCapacity: 1400, engineState: .off, windowState: .open)


trunkCarVolvo.windowState = .open

trunkCarKamaz.trunkFilledCapacity = 1450



printSportCarProperties(car: sportCarMers)

printSportCarProperties(car: sportCarBMW)



printTrunkCarProperties(car: trunkCarVolvo)

printTrunkCarProperties(car: trunkCarKamaz)




